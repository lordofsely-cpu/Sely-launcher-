# Sely Launcher — Foundation Build

This is a **real, buildable Android launcher skeleton** — open it in Android
Studio, hit Run, and you can select "Sely Launcher" as your device's default
Home app. What's here:

- ✅ Registered as a HOME launcher (`AndroidManifest.xml` category.HOME filter)
- ✅ Live app grid pulled from `PackageManager` (not a mock list)
- ✅ Tap to launch, long-press → App info / Uninstall via official Android
  intents (`ACTION_APPLICATION_DETAILS_SETTINGS`, `ACTION_DELETE` — both
  route through the system's own dialogs, never silent)
- ✅ Dark/neon "Sely" visual language: deep-blue background, glass cards,
  rounded corners, blue/purple accents
- ✅ Modular package structure (`com.sely.launcher.*`) so each numbered
  feature in the full spec becomes its own module/Activity/Fragment

## Update — batch 2

Added since the first build:

- **Sely App Drawer** (`drawer/AppDrawerActivity`) — full alphabetical
  app list with live search-by-name filtering, slide-up/down transition.
- **Sely Control Center** (`controlcenter/ControlCenterActivity`) — real
  toggles for Flashlight and Do Not Disturb, working Volume and
  Brightness sliders (brightness gated on the `WRITE_SETTINGS`
  permission, requested inline), and honest deep-links to system
  settings for Wi-Fi/Bluetooth/Airplane mode where Android gives
  third-party apps no direct toggle API — see the comment block at the
  top of `ControlCenterActivity.kt` for the 🟢/🟡/🔴 reasoning per tile.
- **Gesture wiring** (`gesture/HomeGestureListener`) — swipe up on Home
  opens the App Drawer, swipe down opens Control Center.
- Refactored app-loading into `AppRepository` so Home and Drawer share
  one source of truth instead of duplicating `PackageManager` calls.

## Update — batch 3

- **Sely Notification Center** (`notifications/`) — real
  `NotificationListenerService` reading live notifications (app icon,
  title, text), tap to expand/collapse, ✕ to clear one, "Clear all"
  button — all via the official cancel APIs. Gated on Android's
  mandatory Notification Access permission grant, with an in-app prompt
  linking straight to that system screen.
- Gesture routing refined: swipe down from the very top edge (like a
  status-bar shade) opens Notification Center; swipe down elsewhere
  opens Control Center; swipe up still opens the App Drawer.

## Update — batch 4

- **Sely Smart Sidebar** (`sidebar/SidebarActivity`) — right-edge-swipe
  panel with a Favorites grid (reuses `AppRepository`/`AppGridAdapter`)
  and a Tools row (reuses `ControlTile`/`ControlTileAdapter`): real
  Flashlight toggle, real clipboard preview (`ClipboardManager` — works
  reliably here since Android's Android-10+ focus restriction on
  clipboard reads is satisfied by the sidebar being the focused
  window), and real Files/Contacts shortcuts via system intents. Tap
  the dimmed area outside the panel to dismiss.
- **Edge gesture engine** (`gesture/EdgeGestureListener`) — detects a
  horizontal swipe starting within ~24dp of either screen edge; wired
  so a right-edge swipe opens the Sidebar (left edge is detected but
  intentionally unbound for now — natural fit for a future
  back/quick-switch gesture).

## Update — batch 5

- **Sely Theme Engine** (`theme/`) — `ThemeManager` is a single
  persisted source of truth (accent color + dark/light mode via
  SharedPreferences) that every screen reads from. `ThemeActivity` is
  the picker UI: three real accent swatches (Sely Blue/Neon/Purple, tap
  to apply instantly) and a dark/light `Switch`. Long-press empty space
  on Home opens it — the standard launcher pattern.
- Wired live into every existing screen: Home, App Drawer, Control
  Center, and Sidebar all now pull their background/text/accent colors
  from `ThemeManager` in `onResume()`, so switching theme and returning
  to any of them re-skins immediately. `AppGridAdapter` and
  `ControlTileAdapter` were updated to use the live accent/text colors
  instead of hardcoded ones.
- Extending this to each future module is the same three-line pattern
  (see `ThemeManager`'s class doc) — not new engineering per screen.

## Update — batch 6

- **Sely Battery Center + Device Dashboard** (`dashboard/`) — combined
  into one screen, reachable from Control Center's new "Device" tile.
  All real, official-API values, none invented (per spec §12):
  battery percentage/charging/health/temperature from the sticky
  `ACTION_BATTERY_CHANGED` broadcast, RAM from
  `ActivityManager.MemoryInfo`, storage from `StatFs`, device info from
  `Build`. A Battery Saver row deep-links to the real system screen
  (🟡 — no public API lets a non-privileged app flip it directly, same
  pattern as Control Center's Wi-Fi tile). Theme-aware like every other
  screen.

## Update — batch 7

- **Sely Multitask Hub** (`multitask/`), reachable from Control Center's
  new "Recents" tile. **Scope note, stated up front and shown in the
  UI**: Android gives third-party launchers no API to the real system
  Recents list, so this tracks apps launched *through Sely* instead —
  `LaunchHistoryStore` records every launch that goes through
  `AppGridAdapter` (home grid, dock, drawer, sidebar all already route
  through it). Two real sections: "Recent" (most-recently-opened, tap
  to reopen, ✕ to remove from history) and "Frequently used" (ranked by
  actual launch count). "Remove" only edits Sely's own history — it
  does not and cannot force-stop another app's process, since no public
  API allows that either (🔴, noted in the code).

## Update — batch 8

- **Sely Settings** (`SettingsActivity`, rewritten from the original
  stub) — a real menu, reachable from Control Center's new "Settings"
  tile:
  - **Appearance**: Themes → Theme Engine
  - **Launcher**: App Drawer, Control Center, Notification Center,
    Sidebar, Multitasking, Battery & Device — each opens the real
    screen already built
  - **Privacy & Permissions**: three live-status rows — Notification
    access, Modify system settings (Write Settings), and Default
    launcher — each shows the actual current grant/role state (checked
    fresh in `onResume`, so coming back from the system screen it links
    to updates immediately) and taps through to the real system screen
    to change it
  - **About**: app name + tagline
  - Fully theme-aware like every other screen

## Update — batch 9

- **Sely Search** (`search/`) — universal search, opened by tapping the
  Home search bar (previously that opened the App Drawer; Drawer keeps
  its own simpler filter too). Three real sources, combined live as you
  type: installed apps (label match), Settings shortcuts (13 common
  destinations — Wi-Fi, Bluetooth, Battery, Display, Sound, Storage,
  Apps, Location, Airplane mode, Date & time, Security, Accessibility,
  NFC — each a real `Settings.ACTION_*` intent), and contacts via the
  official `CONTENT_FILTER_URI` live-filter query. Contacts only appear
  once `READ_CONTACTS` is granted; an inline banner requests it rather
  than the feature silently returning nothing. No AI, no network — pure
  local filtering, per spec §8. Also linked from Sely Settings.

## Update — batch 10

- **Sely Clipboard Manager** (`clipboard/`), reachable from Control
  Center's "Clipboard" tile, Sely Settings, and by tapping the clip
  preview in the Sidebar. **Scope note, stated up front and in the code
  comments**: since Android 10, only the focused app can read clipboard
  contents — there's no API for a launcher to silently watch clipboard
  changes happening in other apps in the background (real background-
  wide capture needs the app to be an input method or accessibility
  service, a much heavier and more privacy-sensitive feature, deliberately
  not bundled in here). So history grows from clips Sely actually
  observes while it's focused (Sidebar open or Clipboard Manager open),
  via a real `ClipboardManager.OnPrimaryClipChangedListener`. Built:
  persisted history, search, pin/unpin favorites (survive Clear All),
  one-tap copy-back, delete, Clear All.

## Update — batch 11

- **Sely File Hub** (`filehub/`), reachable from Control Center's
  "Files" tile, Sely Settings, and the Sidebar's Files shortcut (which
  previously just opened a bare system picker — now opens the real Hub).
  🟢 Four categories queried live via `MediaStore` — Images, Videos,
  Audio, Downloads — with search, and per-file Open/Share/Delete.
  Delete uses Android's actual scoped-storage flow: a direct
  `ContentResolver.delete()` for files Sely owns, and catching
  `RecoverableSecurityException` to launch the system's own delete-
  confirmation dialog for files it doesn't (the officially sanctioned
  pattern, not a workaround). Permission requests correctly split by
  API level (`READ_MEDIA_IMAGES/VIDEO/AUDIO` on 33+, `READ_EXTERNAL_STORAGE`
  below). 🟡 Documents/APKs/ZIPs/everything else deliberately route
  through the real system file picker (`ACTION_OPEN_DOCUMENT`) instead
  of a fake browse UI — arbitrary file-system access needs
  `MANAGE_EXTERNAL_STORAGE`, a Play-Store-restricted permission that's
  a deliberate scope decision, not something to request quietly. Also
  noted honestly in the code: Downloads visibility for files Sely
  didn't create can vary by OEM on API 33+, since there's no dedicated
  "read all downloads" permission in the modern model.

## What's not built yet

The full prompt specs ~50 subsystems (Control Center, Notification Center,
Sely Transfer/Wi-Fi Direct file sharing, screen recording, gesture engine,
Spaces, automation rules, backup/restore, etc.). Each is a real, multi-day
feature on its own — they're intentionally **not stubbed with fake UI**,
because the spec itself (§48) requires distinguishing real functionality
from pretend functionality:

- 🟢 Fully supported by public Android APIs — safe to build as designed
- 🟡 Permission/OEM-dependent — build it, but degrade gracefully per device
- 🔴 System-restricted (secure lock screen, forced split-screen, silent
  install, system status bar/Recents replacement) — no launcher can do
  these; the closest legitimate alternative should be built instead

## Suggested next module to add

`Sely App Drawer` — a swipe-up sheet listing all apps (same data source as
the home grid) with a search field filtering by label. It reuses
`AppGridAdapter` as-is.

## Build requirements

Android Studio (Koala+), JDK 17, Android SDK 34. No other setup needed —
this project has no external network dependencies beyond standard Maven/
Google repos.
