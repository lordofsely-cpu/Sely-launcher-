package com.sely.launcher.controlcenter

/**
 * One Control Center tile. `onClick` does the real work (see
 * ControlCenterActivity) — every tile here is backed by an actual
 * Android API; nothing pretends to flip a switch it can't reach.
 */
data class ControlTile(
    val label: String,
    val iconRes: Int,
    val onClick: () -> Unit
)
