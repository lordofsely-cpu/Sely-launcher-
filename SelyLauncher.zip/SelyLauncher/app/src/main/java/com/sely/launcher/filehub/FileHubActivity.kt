package com.sely.launcher.filehub

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.RecoverableSecurityException
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.databinding.ActivityFileHubBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely File Hub (spec section 16).
 *
 * See FileHubRepository's class doc for the 🟢/🟡 split between the
 * MediaStore categories (built here, fully real) and Documents/APKs/
 * ZIPs (routed through the system picker instead of a fake browse UI).
 *
 * Permission handling reflects how Android actually split media
 * permissions across versions rather than treating it as one flag:
 *  - API 33+: separate READ_MEDIA_IMAGES / VIDEO / AUDIO
 *  - API < 33: single READ_EXTERNAL_STORAGE
 * Known 🟡 limitation, stated plainly rather than glossed over: on
 * API 33+, MediaStore.Downloads visibility for files Sely didn't create
 * itself can vary by OEM since there's no dedicated "read all downloads"
 * permission in the modern model — if a device shows fewer Downloads
 * entries than expected, that's this platform gap, not a bug to silently
 * paper over.
 *
 * Delete uses the real scoped-storage consent flow: contentResolver.delete()
 * for files Sely owns, and catching RecoverableSecurityException to launch
 * the system's own delete-confirmation UI for files it doesn't (🟢 official
 * pattern, not a workaround).
 */
class FileHubActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFileHubBinding
    private var currentCategory = MediaCategory.IMAGES
    private var currentQuery = ""
    private val permissionRequestCode = 601
    private val deleteRequestCode = 602

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFileHubBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.fileList.layoutManager = LinearLayoutManager(this)
        binding.categoryRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.categoryRow.adapter = CategoryChipAdapter(this, MediaCategory.values().toList(), currentCategory) { category ->
            currentCategory = category
            refresh()
        }

        binding.fileSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentQuery = s?.toString().orEmpty()
                refresh()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.permissionPrompt.setOnClickListener {
            ActivityCompat.requestPermissions(this, requiredPermissions(), permissionRequestCode)
        }

        // 🟡 Real system picker for everything MediaStore doesn't cover
        // directly (Documents, APKs, ZIPs, arbitrary files).
        binding.moreFilesRow.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivity(Intent.createChooser(intent, "Browse files"))
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        refresh()
    }

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                android.Manifest.permission.READ_MEDIA_IMAGES,
                android.Manifest.permission.READ_MEDIA_VIDEO,
                android.Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    private fun hasPermission(): Boolean =
        requiredPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun applyTheme() {
        binding.fileHubRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.fileSearch.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.fileSearch.setTextColor(ThemeManager.textPrimary(this))
        binding.permissionPrompt.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.permissionPrompt.setTextColor(ThemeManager.textPrimary(this))
        binding.emptyState.setTextColor(ThemeManager.textSecondary(this))
        binding.moreFilesRow.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.moreFilesRow.setTextColor(ThemeManager.textSecondary(this))
    }

    private fun refresh() {
        if (!hasPermission()) {
            binding.permissionPrompt.visibility = android.view.View.VISIBLE
            binding.fileList.visibility = android.view.View.GONE
            binding.emptyState.visibility = android.view.View.GONE
            return
        }
        binding.permissionPrompt.visibility = android.view.View.GONE
        binding.fileList.visibility = android.view.View.VISIBLE

        val files = FileHubRepository.query(this, currentCategory, currentQuery)
        binding.emptyState.visibility = if (files.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE

        binding.fileList.adapter = FileAdapter(
            this,
            files,
            onOpen = { file ->
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(file.uri, file.mimeType ?: "*/*")
                    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                try {
                    startActivity(viewIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "No app can open this file", Toast.LENGTH_SHORT).show()
                }
            },
            onShare = { file ->
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = file.mimeType ?: "*/*"
                    putExtra(Intent.EXTRA_STREAM, file.uri)
                    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                startActivity(Intent.createChooser(shareIntent, "Share via"))
            },
            onDelete = { file -> deleteFile(file) }
        )
    }

    private fun deleteFile(file: FileEntry) {
        try {
            contentResolver.delete(file.uri, null, null)
            refresh()
        } catch (e: SecurityException) {
            // 🟢 Official scoped-storage flow: Android hands back an
            // IntentSender that shows the system's own delete-confirmation
            // dialog for files this app doesn't own outright.
            val intentSender = (e as? RecoverableSecurityException)?.userAction?.actionIntent?.intentSender
            if (intentSender != null) {
                startIntentSenderForResult(intentSender, deleteRequestCode, null, 0, 0, 0)
            } else {
                Toast.makeText(this, "Couldn't delete: permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == deleteRequestCode) refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) refresh()
    }
}
