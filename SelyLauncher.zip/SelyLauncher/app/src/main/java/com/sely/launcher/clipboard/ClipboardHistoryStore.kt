package com.sely.launcher.clipboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sely Clipboard Manager (spec section 15) — data layer.
 *
 * 🟡 IMPORTANT SCOPE NOTE: since Android 10, only the focused app can
 * read clipboard contents — there is no public API for a launcher (or
 * any regular app) to silently observe clipboard changes made while
 * some other app is in the foreground. Real background-wide capture
 * needs the app to be an input method or an accessibility service,
 * which is a much more privacy-sensitive capability and a deliberate
 * separate decision, not something to bundle in quietly here.
 *
 * So this store only grows when Sely itself is focused and observes a
 * clip — i.e. whenever ClipboardManagerActivity or the Sidebar is open
 * and registers a ClipboardManager.OnPrimaryClipChangedListener (see
 * both). That's real, honestly-scoped functionality: if you copy
 * something, then open Sely, it's captured from then on.
 */
data class ClipEntry(val text: String, val timestampMillis: Long, val pinned: Boolean)

object ClipboardHistoryStore {

    private const val PREFS = "sely_clipboard_history"
    private const val KEY_ENTRIES = "entries"
    private const val MAX_UNPINNED = 30

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAll(context: Context): List<ClipEntry> {
        val raw = prefs(context).getString(KEY_ENTRIES, "[]") ?: "[]"
        val array = JSONArray(raw)
        val list = mutableListOf<ClipEntry>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(ClipEntry(obj.getString("text"), obj.getLong("ts"), obj.optBoolean("pinned", false)))
        }
        return list.sortedByDescending { it.timestampMillis }
    }

    /** Adds a newly observed clip, deduped against the most recent entry. */
    fun addObservedClip(context: Context, text: String) {
        if (text.isBlank()) return
        val current = getAll(context).toMutableList()
        if (current.firstOrNull()?.text == text) return // no-op if unchanged since last capture

        current.removeAll { it.text == text && !it.pinned }
        current.add(0, ClipEntry(text, System.currentTimeMillis(), false))

        val pinned = current.filter { it.pinned }
        val unpinned = current.filterNot { it.pinned }.take(MAX_UNPINNED)
        save(context, pinned + unpinned)
    }

    fun togglePin(context: Context, entry: ClipEntry) {
        val updated = getAll(context).map {
            if (it.text == entry.text && it.timestampMillis == entry.timestampMillis) it.copy(pinned = !it.pinned) else it
        }
        save(context, updated)
    }

    fun remove(context: Context, entry: ClipEntry) {
        val updated = getAll(context).filterNot { it.text == entry.text && it.timestampMillis == entry.timestampMillis }
        save(context, updated)
    }

    fun clearAll(context: Context) {
        val pinnedOnly = getAll(context).filter { it.pinned }
        save(context, pinnedOnly)
    }

    private fun save(context: Context, entries: List<ClipEntry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(JSONObject().apply {
                put("text", entry.text)
                put("ts", entry.timestampMillis)
                put("pinned", entry.pinned)
            })
        }
        prefs(context).edit().putString(KEY_ENTRIES, array.toString()).apply()
    }
}
