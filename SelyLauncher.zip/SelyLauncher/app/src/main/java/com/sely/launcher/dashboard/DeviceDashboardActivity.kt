package com.sely.launcher.dashboard

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.databinding.ActivityDeviceDashboardBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Battery Center + Device Dashboard (spec sections 12 & 13),
 * combined into one screen since they're both "real numbers, no
 * permission needed, glanceable cards" — matching how most OEM
 * launchers group them under one "About / Status" area.
 *
 * All values come from DeviceStats, which documents exactly which
 * Android API backs each one. Refreshed in onResume so returning here
 * (e.g. after using the phone for a while) always shows current data
 * rather than a stale snapshot.
 */
class DeviceDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDeviceDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDeviceDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.batterySaverLink.setOnClickListener {
            // No public API lets a non-privileged app toggle Battery
            // Saver directly — this deep-links to the real system
            // screen rather than pretending to flip it (🟡, same
            // pattern as the Wi-Fi tile in Control Center).
            startActivity(Intent(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        renderStats()
    }

    private fun applyTheme() {
        val bg = ThemeManager.backgroundColor(this)
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        val accent = ThemeManager.accentColor(this)

        binding.dashboardRoot.setBackgroundColor(bg)
        binding.screenTitle.setTextColor(textPrimary)
        binding.batteryPercent.setTextColor(textPrimary)
        binding.batteryDetail.setTextColor(textSecondary)
        binding.batterySaverLink.setTextColor(accent)
        binding.ramLabel.setTextColor(textSecondary)
        binding.ramDetail.setTextColor(textPrimary)
        binding.storageLabel.setTextColor(textSecondary)
        binding.storageDetail.setTextColor(textPrimary)
        binding.deviceLabel.setTextColor(textSecondary)
        binding.deviceDetail.setTextColor(textPrimary)

        binding.batteryBar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
        binding.ramBar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
        binding.storageBar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
    }

    private fun renderStats() {
        val battery = DeviceStats.battery(this)
        binding.batteryPercent.text = "${battery.percent}%"
        binding.batteryBar.progress = battery.percent
        val tempText = battery.temperatureCelsius?.let { "%.1f°C".format(it) } ?: "n/a"
        binding.batteryDetail.text = buildString {
            append(if (battery.isCharging) "Charging" else "Not charging")
            append(" · ${battery.healthLabel}")
            append(" · $tempText")
        }

        val mem = DeviceStats.memory(this)
        val usedMem = mem.totalBytes - mem.availableBytes
        binding.ramDetail.text = "${DeviceStats.formatBytes(usedMem)} used of ${DeviceStats.formatBytes(mem.totalBytes)}"
        binding.ramBar.progress = ((usedMem.toDouble() / mem.totalBytes) * 100).toInt()

        val storage = DeviceStats.storage()
        val usedStorage = storage.totalBytes - storage.freeBytes
        binding.storageDetail.text = "${DeviceStats.formatBytes(usedStorage)} used of ${DeviceStats.formatBytes(storage.totalBytes)}"
        binding.storageBar.progress = ((usedStorage.toDouble() / storage.totalBytes) * 100).toInt()

        val device = DeviceStats.device()
        binding.deviceDetail.text = "${device.manufacturer} ${device.model} · Android ${device.androidVersion} (API ${device.sdkInt})"
    }
}
