package com.sely.launcher.notifications

import android.content.Intent
import android.os.Bundle
import android.text.format.DateFormat
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.databinding.ActivityNotificationCenterBinding
import java.util.Date

/**
 * Sely Notification Center (spec section 4).
 *
 * Built on this batch:
 *  - permission gate: Android requires explicit user grant of
 *    Notification Access before ANY app can read notifications — Sely
 *    can't skip this, so it detects the missing grant and links
 *    straight to the system screen (🟢 official flow, no workaround)
 *  - live list of current notifications, grouped visually by card
 *  - expand/collapse per notification (tap to toggle)
 *  - clear one notification (✕) and Clear All, both via the real
 *    NotificationListenerService cancel APIs
 *
 * Not yet built: notification history (Android only exposes *history*
 * on some OEM skins, not stock AOSP — needs a 🟡 device-capability
 * check), grouped-by-app collapsing, quick reply (needs reading
 * RemoteInput actions off each Notification and is a good focused
 * next increment), per-app notification controls (deep-link to
 * Settings.ACTION_APP_NOTIFICATION_SETTINGS, same pattern as Control
 * Center's Wi-Fi tile).
 */
class NotificationCenterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationCenterBinding
    private val onNotificationsChanged = { refreshList() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationCenterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.dateTime.text = DateFormat.format("EEEE, MMM d · h:mm a", Date())
        binding.notificationList.layoutManager = LinearLayoutManager(this)

        binding.permissionPrompt.setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        binding.clearAll.setOnClickListener {
            SelyNotificationListenerService.instance?.clearAll()
            refreshList()
        }

        SelyNotificationListenerService.addChangeListener(onNotificationsChanged)
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    override fun onDestroy() {
        super.onDestroy()
        SelyNotificationListenerService.removeChangeListener(onNotificationsChanged)
    }

    private fun refreshList() {
        val granted = SelyNotificationListenerService.isEnabled(this)
        binding.permissionPrompt.visibility = if (granted) android.view.View.GONE else android.view.View.VISIBLE
        if (!granted) {
            binding.notificationList.visibility = android.view.View.GONE
            binding.emptyState.visibility = android.view.View.GONE
            return
        }
        binding.notificationList.visibility = android.view.View.VISIBLE

        val notifications = SelyNotificationListenerService.instance
            ?.activeNotifications
            ?.filter { !it.notification.flags.and(android.app.Notification.FLAG_ONGOING_EVENT).let { f -> f != 0 } }
            ?.sortedByDescending { it.postTime }
            ?: emptyList()

        binding.emptyState.visibility = if (notifications.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE

        binding.notificationList.adapter = NotificationAdapter(this, notifications) { key ->
            SelyNotificationListenerService.instance?.clearOne(key)
            refreshList()
        }
    }
}
