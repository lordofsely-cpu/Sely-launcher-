package com.sely.launcher.controlcenter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R

class ControlTileAdapter(
    private val context: Context,
    private val tiles: List<ControlTile>
) : RecyclerView.Adapter<ControlTileAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.tileIcon)
        val label: TextView = view.findViewById(R.id.tileLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_tile, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = tiles.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tile = tiles[position]
        holder.icon.setImageResource(tile.iconRes)
        holder.icon.setColorFilter(com.sely.launcher.theme.ThemeManager.accentColor(context))
        holder.label.text = tile.label
        holder.label.setTextColor(com.sely.launcher.theme.ThemeManager.textPrimary(context))
        holder.itemView.setOnClickListener { tile.onClick() }
    }
}
