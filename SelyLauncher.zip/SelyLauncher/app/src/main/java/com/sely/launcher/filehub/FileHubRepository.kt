package com.sely.launcher.filehub

import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/**
 * Sely File Hub (spec section 16) — data layer.
 *
 * 🟢 Images, Video, Audio, Downloads — all queried live via MediaStore,
 * Android's official media index. No special permission needed beyond
 * the standard runtime media permissions (see FileHubActivity), and no
 * risk of showing stale data: this always reflects what's actually on
 * the device right now.
 *
 * 🟡 Documents / APKs / ZIPs / "everything else" are deliberately NOT
 * queried directly here. Since Android 10 (scoped storage), an app can
 * only get that kind of arbitrary-file access via MANAGE_EXTERNAL_STORAGE
 * — a permission Google Play restricts to file-manager-class apps and
 * that would be a significant, deliberate scope increase for a launcher
 * to request. FileHubActivity instead routes those categories through
 * Android's own system file picker (ACTION_OPEN_DOCUMENT /
 * ACTION_VIEW), which is the real, sanctioned way to reach them.
 */
data class FileEntry(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val dateModifiedSeconds: Long,
    val mimeType: String?
)

enum class MediaCategory(val label: String, val collection: Uri) {
    IMAGES("Images", MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
    VIDEOS("Videos", MediaStore.Video.Media.EXTERNAL_CONTENT_URI),
    AUDIO("Audio", MediaStore.Audio.Media.EXTERNAL_CONTENT_URI),
    DOWNLOADS("Downloads", MediaStore.Downloads.EXTERNAL_CONTENT_URI)
}

object FileHubRepository {

    fun query(context: Context, category: MediaCategory, searchQuery: String = ""): List<FileEntry> {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.MIME_TYPE
        )

        val selection = if (searchQuery.isNotBlank()) "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?" else null
        val selectionArgs = if (searchQuery.isNotBlank()) arrayOf("%$searchQuery%") else null
        val sortOrder = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"

        val results = mutableListOf<FileEntry>()
        context.contentResolver.query(category.collection, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = Uri.withAppendedPath(category.collection, id.toString())
                results.add(
                    FileEntry(
                        uri = uri,
                        name = cursor.getString(nameCol) ?: "Unknown",
                        sizeBytes = cursor.getLong(sizeCol),
                        dateModifiedSeconds = cursor.getLong(dateCol),
                        mimeType = cursor.getString(mimeCol)
                    )
                )
            }
        }
        return results
    }

    fun formatSize(bytes: Long): String {
        val mb = bytes / 1_048_576.0
        return if (mb >= 1) "%.1f MB".format(mb) else "%.0f KB".format(bytes / 1024.0)
    }
}
