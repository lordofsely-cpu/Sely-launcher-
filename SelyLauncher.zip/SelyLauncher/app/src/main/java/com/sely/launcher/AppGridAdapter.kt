package com.sely.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter shared by the home grid and the dock.
 *
 * Long-press shows only actions Android actually exposes for a launcher:
 * App info (ACTION_APPLICATION_DETAILS_SETTINGS) and Uninstall
 * (ACTION_DELETE, which routes through the system confirmation dialog —
 * Sely never uninstalls silently). Anything not backed by a real API
 * (e.g. "split screen") is intentionally left out of this foundation
 * build rather than faked; see the 🟢/🟡/🔴 compatibility note in the
 * project README before adding more actions.
 */
class AppGridAdapter(
    private val context: Context,
    private val apps: List<AppInfo>
) : RecyclerView.Adapter<AppGridAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = apps.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.setTextColor(com.sely.launcher.theme.ThemeManager.textPrimary(context))

        holder.itemView.setOnClickListener { launch(app) }
        holder.itemView.setOnLongClickListener { anchor ->
            showActionMenu(anchor, app)
            true
        }
    }

    private fun launch(app: AppInfo) {
        com.sely.launcher.multitask.LaunchHistoryStore.recordLaunch(context, app.packageName, app.activityName)
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    private fun showActionMenu(anchor: View, app: AppInfo) {
        val menu = PopupMenu(context, anchor)
        menu.menu.add("Open")
        menu.menu.add("App info")
        menu.menu.add("Uninstall")
        menu.setOnMenuItemClickListener { item ->
            when (item.title) {
                "Open" -> launch(app)
                "App info" -> openAppInfo(app)
                "Uninstall" -> uninstall(app)
            }
            true
        }
        menu.show()
    }

    private fun openAppInfo(app: AppInfo) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${app.packageName}")
        }
        context.startActivity(intent)
    }

    private fun uninstall(app: AppInfo) {
        // ACTION_DELETE hands off to the system's own confirmation dialog —
        // Sely never uninstalls without the user explicitly confirming there.
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${app.packageName}")
        }
        context.startActivity(intent)
    }
}
