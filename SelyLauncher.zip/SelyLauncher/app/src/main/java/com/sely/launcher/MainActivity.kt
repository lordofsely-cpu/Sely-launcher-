package com.sely.launcher

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.controlcenter.ControlCenterActivity
import com.sely.launcher.databinding.ActivityMainBinding
import com.sely.launcher.drawer.AppDrawerActivity
import com.sely.launcher.notifications.NotificationCenterActivity
import com.sely.launcher.gesture.HomeGestureListener
import com.sely.launcher.gesture.EdgeGestureListener
import com.sely.launcher.search.SearchActivity
import com.sely.launcher.sidebar.SidebarActivity
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Home. This is the real HOME activity (see AndroidManifest's
 * category.HOME intent-filter) — selecting Sely Launcher as the default
 * launcher will bring the user here on every Home press.
 *
 * This foundation build wires up:
 *  - live app list from PackageManager (🟢 fully supported)
 *  - tap to launch, long-press for App info / Uninstall (🟢 official APIs)
 *  - dock of the first few apps as a stand-in for a configurable dock
 *
 * Not yet implemented (each is its own module per the project spec):
 * app drawer, control center, notification center, sidebar, gestures,
 * widgets, themes, Sely Transfer, etc. Build each as a separate Activity/
 * Fragment module under com.sely.launcher.<module> so this stays
 * maintainable as it grows.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var gestureListener: HomeGestureListener
    private lateinit var edgeGestureListener: EdgeGestureListener
    private lateinit var homeAdapter: AppGridAdapter
    private lateinit var dockAdapter: AppGridAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val apps = AppRepository.loadLaunchableApps(this)

        binding.homeGrid.layoutManager = GridLayoutManager(this, 4)
        homeAdapter = AppGridAdapter(this, apps)
        binding.homeGrid.adapter = homeAdapter

        binding.dock.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        dockAdapter = AppGridAdapter(this, apps.take(5))
        binding.dock.adapter = dockAdapter

        binding.searchBar.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }

        // Long-press empty home space -> Sely Theme (matches the common
        // launcher pattern of long-press-for-wallpaper-and-theme-options).
        binding.root.setOnLongClickListener {
            startActivity(Intent(this, com.sely.launcher.theme.ThemeActivity::class.java))
            true
        }

        // Swipe up anywhere on the home screen -> App Drawer.
        // Swipe down starting near the top edge -> Notification Center
        // (matches how status-bar shades work everywhere else).
        // Swipe down starting lower on the screen -> Control Center.
        val topEdgePx = resources.displayMetrics.density * 80
        gestureListener = HomeGestureListener(
            context = this,
            onSwipeUp = { startActivity(Intent(this, AppDrawerActivity::class.java)) },
            onSwipeDown = { startY ->
                if (startY < topEdgePx) {
                    startActivity(Intent(this, NotificationCenterActivity::class.java))
                } else {
                    startActivity(Intent(this, ControlCenterActivity::class.java))
                }
            }
        )

        // Swipe in from the right edge -> Sely Smart Sidebar.
        // (Left-edge swipe is detected too but unused for now — reserved
        // for a future "back"/quick-switch gesture.)
        edgeGestureListener = EdgeGestureListener(
            context = this,
            screenWidthPx = resources.displayMetrics.widthPixels,
            edgeWidthPx = (resources.displayMetrics.density * 24).toInt(),
            onEdgeSwipe = { fromRightEdge ->
                if (fromRightEdge) startActivity(Intent(this, SidebarActivity::class.java))
            }
        )
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestureListener.detector.onTouchEvent(ev)
        edgeGestureListener.detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
    }

    /** Re-reads ThemeManager and re-skins Home — same pattern used by
     * every other screen (Drawer, Control Center, Sidebar, Theme picker). */
    private fun applyTheme() {
        binding.root.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.searchBar.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.searchBar.setTextColor(ThemeManager.textSecondary(this))
        binding.dock.setBackgroundColor(ThemeManager.dockColor(this))
        homeAdapter.notifyDataSetChanged()
        dockAdapter.notifyDataSetChanged()
    }

    // Back press on Home should do nothing (standard launcher behavior),
    // not fall through to the previous app.
    override fun onBackPressed() {
        // intentionally empty
    }
}
