package com.sely.launcher.search

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class SearchResultAdapter(
    private val context: Context,
    private val results: List<SearchResult>,
    private val onClick: (SearchResult) -> Unit
) : RecyclerView.Adapter<SearchResultAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.resultIcon)
        val label: TextView = view.findViewById(R.id.resultLabel)
        val type: TextView = view.findViewById(R.id.resultType)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_search_result, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = results.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val result = results[position]
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.type.setTextColor(ThemeManager.accentColor(context))

        when (result) {
            is SearchResult.AppResult -> {
                holder.icon.setImageDrawable(result.app.icon)
                holder.label.text = result.app.label
                holder.type.text = "App"
            }
            is SearchResult.SettingsResult -> {
                holder.icon.setImageResource(android.R.drawable.ic_menu_manage)
                holder.icon.setColorFilter(ThemeManager.accentColor(context))
                holder.label.text = result.label
                holder.type.text = "Settings"
            }
            is SearchResult.ContactResult -> {
                holder.icon.setImageResource(android.R.drawable.ic_menu_call)
                holder.icon.setColorFilter(ThemeManager.accentColor(context))
                holder.label.text = result.name
                holder.type.text = "Contact"
            }
        }

        holder.itemView.setOnClickListener { onClick(result) }
    }
}
