package com.sely.launcher.search

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.databinding.ActivitySearchBinding
import com.sely.launcher.multitask.LaunchHistoryStore
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Search (spec section 8) — universal launcher search.
 *
 * Combines three real sources as the user types (see SearchRepository
 * for the API each is backed by): installed apps, Settings shortcuts,
 * and contacts. Contacts only appear once READ_CONTACTS is granted —
 * the permission banner requests it inline rather than the feature
 * silently doing nothing.
 *
 * No AI, no network calls — pure local filtering, per spec §8.
 */
class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private val contactsRequestCode = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.resultsList.layoutManager = LinearLayoutManager(this)

        binding.contactsPermissionRow.setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), contactsRequestCode)
        }

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                runSearch(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        val contactsGranted = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        binding.contactsPermissionRow.visibility = if (contactsGranted) android.view.View.GONE else android.view.View.VISIBLE
        runSearch(binding.searchInput.text?.toString().orEmpty())
    }

    private fun applyTheme() {
        binding.searchRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.searchInput.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.searchInput.setTextColor(ThemeManager.textPrimary(this))
        binding.searchInput.setHintTextColor(ThemeManager.textSecondary(this))
        binding.contactsPermissionRow.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.contactsPermissionRow.setTextColor(ThemeManager.textSecondary(this))
    }

    private fun runSearch(query: String) {
        val results: List<SearchResult> =
            SearchRepository.searchApps(this, query) +
            SearchRepository.searchSettings(query) +
            SearchRepository.searchContacts(this, query)

        binding.resultsList.adapter = SearchResultAdapter(this, results) { result -> openResult(result) }
    }

    private fun openResult(result: SearchResult) {
        when (result) {
            is SearchResult.AppResult -> {
                LaunchHistoryStore.recordLaunch(this, result.app.packageName, result.app.activityName)
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    component = ComponentName(result.app.packageName, result.app.activityName)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
            }
            is SearchResult.SettingsResult -> startActivity(Intent(result.intentAction))
            is SearchResult.ContactResult -> startActivity(Intent(Intent.ACTION_VIEW, result.lookupUri))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == contactsRequestCode) {
            binding.contactsPermissionRow.visibility =
                if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) android.view.View.GONE
                else android.view.View.VISIBLE
            runSearch(binding.searchInput.text?.toString().orEmpty())
        }
    }
}
