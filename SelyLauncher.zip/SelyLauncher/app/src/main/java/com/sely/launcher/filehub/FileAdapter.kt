package com.sely.launcher.filehub

import android.content.Context
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class FileAdapter(
    private val context: Context,
    private val files: List<FileEntry>,
    private val onOpen: (FileEntry) -> Unit,
    private val onShare: (FileEntry) -> Unit,
    private val onDelete: (FileEntry) -> Unit
) : RecyclerView.Adapter<FileAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.fileName)
        val meta: TextView = view.findViewById(R.id.fileMeta)
        val share: TextView = view.findViewById(R.id.fileShare)
        val delete: TextView = view.findViewById(R.id.fileDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_file, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = files.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = files[position]
        holder.name.text = file.name
        holder.name.setTextColor(ThemeManager.textPrimary(context))
        val dateText = DateFormat.format("MMM d, yyyy", file.dateModifiedSeconds * 1000)
        holder.meta.text = "${FileHubRepository.formatSize(file.sizeBytes)} · $dateText"
        holder.meta.setTextColor(ThemeManager.textSecondary(context))
        holder.share.setTextColor(ThemeManager.accentColor(context))
        holder.delete.setTextColor(ThemeManager.textSecondary(context))

        holder.itemView.setOnClickListener { onOpen(file) }
        holder.share.setOnClickListener { onShare(file) }
        holder.delete.setOnClickListener { onDelete(file) }
    }
}
