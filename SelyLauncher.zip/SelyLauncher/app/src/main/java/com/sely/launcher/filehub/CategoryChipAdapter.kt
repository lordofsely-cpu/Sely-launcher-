package com.sely.launcher.filehub

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class CategoryChipAdapter(
    private val context: Context,
    private val categories: List<MediaCategory>,
    private var selected: MediaCategory,
    private val onSelect: (MediaCategory) -> Unit
) : RecyclerView.Adapter<CategoryChipAdapter.ViewHolder>() {

    class ViewHolder(val view: TextView) : RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_category_chip, parent, false) as TextView
        return ViewHolder(v)
    }

    override fun getItemCount() = categories.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category = categories[position]
        holder.view.text = category.label
        val isSelected = category == selected
        holder.view.setTextColor(if (isSelected) ThemeManager.accentColor(context) else ThemeManager.textSecondary(context))
        holder.view.setOnClickListener {
            selected = category
            onSelect(category)
            notifyDataSetChanged()
        }
    }
}
