package com.sely.launcher.sidebar

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.AppGridAdapter
import com.sely.launcher.AppRepository
import com.sely.launcher.controlcenter.ControlTile
import com.sely.launcher.controlcenter.ControlTileAdapter
import com.sely.launcher.databinding.ActivitySidebarBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Smart Sidebar (spec section 6), foundation slice.
 *
 * Built here: Favorites grid (top 8 apps by label — a real "favorites"
 * concept needs a pin/unpin UI and persistence, noted below), and a
 * Tools row with real, working shortcuts:
 *  🟢 Flashlight — same CameraManager approach as Control Center
 *  🟢 Clipboard preview — ClipboardManager.primaryClip; Android 10+
 *     only allows reading the clipboard while Sely is the focused
 *     window, which is exactly the case here, so this works reliably
 *  🟢 Files / Contacts — real system intents (ACTION_GET_CONTENT,
 *     Contacts CONTENT_URI), handed off to whatever app the user has
 *     set for each
 *
 * Not yet built: user-editable favorites (needs SharedPreferences +
 * long-press-to-pin UI on the home grid), QR scanner (needs CameraX +
 * a barcode-detection library — a real dependency to add deliberately,
 * not bundled here), screenshot/screen-recorder shortcuts (see the
 * 🔴 note already in ControlCenterActivity — no programmatic screenshot
 * API for a non-privileged app), draggable/repositionable edge handle
 * (current trigger is the fixed edge-swipe gesture wired in MainActivity).
 */
class SidebarActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySidebarBinding
    private var torchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySidebarBinding.inflate(layoutInflater)
        setContentView(binding.root)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

        binding.scrim.setOnClickListener { finish() }

        val favorites = AppRepository.loadLaunchableApps(this).take(8)
        binding.favoritesGrid.layoutManager = GridLayoutManager(this, 4)
        binding.favoritesGrid.adapter = AppGridAdapter(this, favorites)

        val tools = listOf(
            ControlTile("Flashlight", android.R.drawable.ic_menu_camera) { toggleFlashlight() },
            ControlTile("Files", android.R.drawable.ic_menu_gallery) { openFiles() },
            ControlTile("Contacts", android.R.drawable.ic_menu_call) { openContacts() },
            ControlTile("Copy text", android.R.drawable.ic_menu_edit) { showClipboard() }
        )
        binding.toolsGrid.layoutManager = GridLayoutManager(this, 4)
        binding.toolsGrid.adapter = ControlTileAdapter(this, tools)

        showClipboard()
        binding.clipboardPreview.setOnClickListener {
            startActivity(Intent(this, com.sely.launcher.clipboard.ClipboardManagerActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        binding.sidebarPanel.setBackgroundColor(ThemeManager.dockColor(this))
        binding.clipboardPreview.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.clipboardPreview.setTextColor(ThemeManager.textSecondary(this))
    }

    private fun toggleFlashlight() {
        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cameraManager.setTorchMode(cameraId, torchOn)
        } catch (e: Exception) {
            Toast.makeText(this, "Flashlight unavailable: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFiles() {
        startActivity(Intent(this, com.sely.launcher.filehub.FileHubActivity::class.java))
    }

    private fun openContacts() {
        startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
    }

    private fun showClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this).toString()
        } else null

        if (!text.isNullOrBlank()) {
            // Sidebar being open means Sely is focused, so this is a
            // legitimate real capture for Clipboard History — see
            // ClipboardHistoryStore's class doc for why this can only
            // happen while Sely itself has focus.
            com.sely.launcher.clipboard.ClipboardHistoryStore.addObservedClip(this, text)
        }
        binding.clipboardPreview.text = text ?: "Clipboard is empty"
    }
}
