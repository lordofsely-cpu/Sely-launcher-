package com.sely.launcher.theme

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.databinding.ActivityThemeBinding

/**
 * Sely Theme picker UI. Every tap here writes through ThemeManager
 * immediately (no separate "Save" step) so switching themes feels live,
 * matching how every commercial launcher's theme screen behaves.
 *
 * This screen itself re-skins on resume using the same
 * ThemeManager.* getters every other screen uses — it's both a control
 * panel and a working example of the pattern to copy into new screens.
 */
class ThemeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityThemeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThemeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        buildSwatches()

        binding.darkModeSwitch.isChecked = ThemeManager.isDark(this)
        binding.darkModeSwitch.setOnCheckedChangeListener { _, checked ->
            ThemeManager.setDark(this, checked)
            applyTheme()
        }

        applyTheme()
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
    }

    private fun buildSwatches() {
        binding.swatchRow.removeAllViews()
        val sizePx = (52 * resources.displayMetrics.density).toInt()
        val marginPx = (10 * resources.displayMetrics.density).toInt()

        ThemeManager.Preset.values().forEach { preset ->
            val swatch = android.widget.ImageView(this)
            val params = LinearLayout.LayoutParams(sizePx, sizePx)
            params.marginEnd = marginPx
            swatch.layoutParams = params

            val color = getColor(preset.colorRes)
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                if (ThemeManager.accentColor(this@ThemeActivity) == color) {
                    setStroke((3 * resources.displayMetrics.density).toInt(), getColor(android.R.color.white))
                }
            }
            swatch.setImageDrawable(drawable)
            swatch.setOnClickListener {
                ThemeManager.setAccentColor(this, color)
                buildSwatches()
                applyTheme()
            }
            binding.swatchRow.addView(swatch)
        }
    }

    private fun applyTheme() {
        binding.themeRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        binding.screenTitle.setTextColor(textPrimary)
        binding.accentLabel.setTextColor(textSecondary)
        binding.darkModeLabel.setTextColor(textPrimary)
    }
}
