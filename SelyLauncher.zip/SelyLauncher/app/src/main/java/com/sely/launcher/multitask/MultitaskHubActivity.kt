package com.sely.launcher.multitask

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.AppGridAdapter
import com.sely.launcher.AppInfo
import com.sely.launcher.AppRepository
import com.sely.launcher.databinding.ActivityMultitaskHubBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Multitask Hub (spec section 5), foundation slice.
 *
 * Scope, stated plainly (also shown to the user in `scopeNote`):
 * this shows apps launched *through Sely*, not the OS Recents list —
 * no third-party launcher API exists for the latter (🔴). "Remove" on
 * an entry removes it from this history; it does not and cannot force-
 * stop the app's process (also 🔴 — no public API for one app to kill
 * another's process). Real and useful on its own terms, just not
 * mislabeled as something Android doesn't let it be.
 *
 * Not yet built: app pairs / saved workspaces (section 29 — a natural
 * extension once this data model exists), split-screen/PiP shortcuts
 * (🟡 device/OEM-dependent, via Intent flags where supported).
 */
class MultitaskHubActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMultitaskHubBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMultitaskHubBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recentList.layoutManager = LinearLayoutManager(this)
        binding.frequentGrid.layoutManager = GridLayoutManager(this, 4)

        binding.clearAll.setOnClickListener {
            LaunchHistoryStore.clearAll(this)
            render()
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        render()
    }

    private fun applyTheme() {
        val bg = ThemeManager.backgroundColor(this)
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        val accent = ThemeManager.accentColor(this)

        binding.hubRoot.setBackgroundColor(bg)
        binding.screenTitle.setTextColor(textPrimary)
        binding.scopeNote.setTextColor(textSecondary)
        binding.emptyState.setTextColor(textSecondary)
        binding.clearAll.setTextColor(accent)
        binding.frequentLabel.setTextColor(textSecondary)
    }

    private fun render() {
        val recentApps = LaunchHistoryStore.getRecent(this)
            .mapNotNull { (pkg, activity) -> AppRepository.resolveApp(this, pkg, activity) }

        binding.emptyState.visibility = if (recentApps.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.recentList.visibility = if (recentApps.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE

        binding.recentList.adapter = RecentAppAdapter(
            this,
            recentApps,
            onOpen = { app -> openApp(app) },
            onRemove = { app ->
                LaunchHistoryStore.removeFromHistory(this, app.packageName)
                render()
            }
        )

        val frequentApps: List<AppInfo> = LaunchHistoryStore.getFrequent(this, 8)
            .mapNotNull { pkg ->
                val entry = LaunchHistoryStore.getRecent(this).firstOrNull { it.first == pkg }
                entry?.let { (p, a) -> AppRepository.resolveApp(this, p, a) }
            }
        binding.frequentLabel.visibility = if (frequentApps.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
        binding.frequentGrid.visibility = if (frequentApps.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
        binding.frequentGrid.adapter = AppGridAdapter(this, frequentApps)
    }

    private fun openApp(app: AppInfo) {
        LaunchHistoryStore.recordLaunch(this, app.packageName, app.activityName)
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }
}
