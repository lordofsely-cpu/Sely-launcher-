package com.sely.launcher.notifications

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Sely Notification Center (spec section 4) — data source.
 *
 * 🟢 This is Android's real, official API for a launcher/app to see
 * other apps' notifications. It requires the user to explicitly grant
 * "Notification access" in system settings (there is no way around
 * that, by design — see NotificationCenterActivity.ensurePermission()).
 *
 * The service keeps a static reference to itself while connected so the
 * UI can pull `activeNotifications` and call cancel*() directly, and
 * notifies a simple listener list on change so the UI can refresh live
 * instead of polling.
 */
class SelyNotificationListenerService : NotificationListenerService() {

    companion object {
        var instance: SelyNotificationListenerService? = null
        private val listeners = mutableListOf<() -> Unit>()

        fun addChangeListener(listener: () -> Unit) = listeners.add(listener)
        fun removeChangeListener(listener: () -> Unit) = listeners.remove(listener)
        private fun notifyChanged() = listeners.forEach { it() }

        fun isEnabled(context: android.content.Context): Boolean {
            val enabledListeners = android.provider.Settings.Secure.getString(
                context.contentResolver, "enabled_notification_listeners"
            ) ?: return false
            return enabledListeners.contains(context.packageName)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        notifyChanged()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        notifyChanged()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        notifyChanged()
    }

    /** Clear one notification (🟢 official API — respects ongoing/non-clearable flags). */
    fun clearOne(key: String) = cancelNotification(key)

    /** Clear everything the user is allowed to clear (🟢 official API). */
    fun clearAll() = cancelAllNotifications()
}
