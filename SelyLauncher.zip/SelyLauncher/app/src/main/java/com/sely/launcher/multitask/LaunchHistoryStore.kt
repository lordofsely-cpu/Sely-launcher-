package com.sely.launcher.multitask

import android.content.Context

/**
 * Backing store for Sely Multitask Hub (spec section 5).
 *
 * IMPORTANT SCOPE NOTE: Android does not expose the system's real
 * Recents list to third-party launchers — there is no public API for
 * it. What this tracks instead is real and honest on its own terms:
 * every app the user has actually opened *through Sely* (home grid,
 * dock, drawer, or sidebar — anywhere routed through AppGridAdapter),
 * most-recent-first, plus a launch-count table for "frequently used".
 * That's a genuine, useful feature; it's just not a Recents replacement,
 * and the UI (MultitaskHubActivity) labels it accordingly rather than
 * implying it's the OS-level task list.
 *
 * Persisted as plain SharedPreferences — 🟢 no permission needed.
 */
object LaunchHistoryStore {

    private const val PREFS = "sely_launch_history"
    private const val KEY_RECENT = "recent_order"
    private const val MAX_HISTORY = 20
    private const val ENTRY_SEP = ";;"
    private const val FIELD_SEP = "|||"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Call this every time Sely launches an app on the user's behalf. */
    fun recordLaunch(context: Context, packageName: String, activityName: String) {
        val p = prefs(context)
        val entry = "$packageName$FIELD_SEP$activityName"

        val current = getRawRecent(context).toMutableList()
        current.removeAll { it == entry }
        current.add(0, entry)
        while (current.size > MAX_HISTORY) current.removeAt(current.size - 1)

        val countKey = "count_$packageName"
        val newCount = p.getInt(countKey, 0) + 1

        p.edit()
            .putString(KEY_RECENT, current.joinToString(ENTRY_SEP))
            .putInt(countKey, newCount)
            .apply()
    }

    /** Most-recently-launched-through-Sely apps, newest first. */
    fun getRecent(context: Context): List<Pair<String, String>> =
        getRawRecent(context).map {
            val parts = it.split(FIELD_SEP)
            parts[0] to parts.getOrElse(1) { "" }
        }

    /** Package names ranked by how often they've been launched through Sely. */
    fun getFrequent(context: Context, limit: Int): List<String> {
        val p = prefs(context)
        return getRawRecent(context)
            .map { it.split(FIELD_SEP)[0] }
            .distinct()
            .sortedByDescending { p.getInt("count_$it", 0) }
            .take(limit)
    }

    fun removeFromHistory(context: Context, packageName: String) {
        val current = getRawRecent(context).filterNot { it.startsWith("$packageName$FIELD_SEP") }
        prefs(context).edit().putString(KEY_RECENT, current.joinToString(ENTRY_SEP)).apply()
    }

    fun clearAll(context: Context) {
        prefs(context).edit().clear().apply()
    }

    private fun getRawRecent(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_RECENT, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(ENTRY_SEP)
    }
}
