package com.sely.launcher.clipboard

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.databinding.ActivityClipboardBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Clipboard Manager (spec section 15).
 *
 * See ClipboardHistoryStore's class doc for the platform limitation
 * this respects: history only grows from clips observed while Sely
 * itself is the focused app. This screen registers a real
 * ClipboardManager.OnPrimaryClipChangedListener while it's on screen
 * (🟢 official API, works reliably here since the activity is focused),
 * and also captures whatever is already on the clipboard on open.
 */
class ClipboardManagerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityClipboardBinding
    private lateinit var clipboardManager: ClipboardManager
    private var currentQuery = ""

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        captureCurrentClip()
        render()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityClipboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        binding.clipList.layoutManager = LinearLayoutManager(this)

        binding.clearAll.setOnClickListener {
            ClipboardHistoryStore.clearAll(this)
            render()
        }

        binding.clipSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentQuery = s?.toString().orEmpty()
                render()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        captureCurrentClip()
        clipboardManager.addPrimaryClipChangedListener(clipListener)
        render()
    }

    override fun onPause() {
        super.onPause()
        clipboardManager.removePrimaryClipChangedListener(clipListener)
    }

    private fun captureCurrentClip() {
        val clip = clipboardManager.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString()
            if (!text.isNullOrBlank()) ClipboardHistoryStore.addObservedClip(this, text)
        }
    }

    private fun applyTheme() {
        binding.clipboardRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.clearAll.setTextColor(ThemeManager.accentColor(this))
        binding.clipSearch.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.clipSearch.setTextColor(ThemeManager.textPrimary(this))
        binding.emptyState.setTextColor(ThemeManager.textSecondary(this))
    }

    private fun render() {
        val all = ClipboardHistoryStore.getAll(this)
        val filtered = if (currentQuery.isBlank()) all else all.filter { it.text.contains(currentQuery, ignoreCase = true) }

        binding.emptyState.visibility = if (all.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.clipList.visibility = if (all.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE

        binding.clipList.adapter = ClipAdapter(this, filtered) { render() }
    }
}
