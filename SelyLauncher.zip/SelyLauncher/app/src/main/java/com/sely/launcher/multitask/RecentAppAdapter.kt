package com.sely.launcher.multitask

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.AppInfo
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class RecentAppAdapter(
    private val context: Context,
    private val apps: List<AppInfo>,
    private val onOpen: (AppInfo) -> Unit,
    private val onRemove: (AppInfo) -> Unit
) : RecyclerView.Adapter<RecentAppAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.recentIcon)
        val label: TextView = view.findViewById(R.id.recentLabel)
        val remove: TextView = view.findViewById(R.id.recentRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_recent_app, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = apps.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.remove.setTextColor(ThemeManager.textSecondary(context))
        holder.itemView.setOnClickListener { onOpen(app) }
        holder.remove.setOnClickListener { onRemove(app) }
    }
}
