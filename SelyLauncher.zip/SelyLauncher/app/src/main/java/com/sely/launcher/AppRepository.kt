package com.sely.launcher

import android.content.Context
import android.content.Intent

/** Single source of truth for "what apps are installed and launchable". */
object AppRepository {

    fun loadLaunchableApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { resolveInfo ->
                AppInfo(
                    label = resolveInfo.loadLabel(pm).toString(),
                    packageName = resolveInfo.activityInfo.packageName,
                    activityName = resolveInfo.activityInfo.name,
                    icon = resolveInfo.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    /**
     * Resolves a single app by package/activity name, for screens (like
     * Multitask Hub) that persist just those two strings and need to
     * look up a fresh icon/label later. Returns null if the app has
     * since been uninstalled, so callers can drop it quietly instead of
     * showing a broken entry.
     */
    fun resolveApp(context: Context, packageName: String, activityName: String): AppInfo? {
        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            AppInfo(
                label = pm.getApplicationLabel(appInfo).toString(),
                packageName = packageName,
                activityName = activityName,
                icon = pm.getApplicationIcon(appInfo)
            )
        } catch (e: Exception) {
            null
        }
    }
}
