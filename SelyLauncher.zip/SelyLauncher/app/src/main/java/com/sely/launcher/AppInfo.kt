package com.sely.launcher

import android.graphics.drawable.Drawable

/** Minimal model for one launchable app, resolved from PackageManager. */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)
