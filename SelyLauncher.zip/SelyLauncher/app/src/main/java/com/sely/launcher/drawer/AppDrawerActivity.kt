package com.sely.launcher.drawer

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.AppGridAdapter
import com.sely.launcher.AppInfo
import com.sely.launcher.AppRepository
import com.sely.launcher.R
import com.sely.launcher.databinding.ActivityAppDrawerBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely App Drawer (spec section 2). Foundation build covers:
 *  - full alphabetical app list (🟢 PackageManager)
 *  - live search-by-name filtering (🟢 local, no extra permission)
 *
 * Not yet built here: categories, recents/frequently-used tracking,
 * hidden apps, custom drawer grid size, per-app icon overrides — each
 * needs its own small persistence layer (SharedPreferences/Room) and is
 * a good next increment on top of this file.
 */
class AppDrawerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppDrawerBinding
    private lateinit var allApps: List<AppInfo>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        overridePendingTransition(R.anim.slide_up_in, R.anim.no_anim)

        allApps = AppRepository.loadLaunchableApps(this)

        binding.drawerGrid.layoutManager = GridLayoutManager(this, 4)
        renderList(allApps)

        binding.drawerSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString()?.trim()?.lowercase().orEmpty()
                renderList(if (query.isEmpty()) allApps else allApps.filter {
                    it.label.lowercase().contains(query)
                })
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun renderList(apps: List<AppInfo>) {
        binding.drawerGrid.adapter = AppGridAdapter(this, apps)
    }

    override fun onResume() {
        super.onResume()
        binding.root.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.drawerSearch.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.drawerSearch.setTextColor(ThemeManager.textPrimary(this))
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.no_anim, R.anim.slide_down_out)
    }
}
