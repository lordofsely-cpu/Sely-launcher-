package com.sely.launcher.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class ClipAdapter(
    private val context: Context,
    private val entries: List<ClipEntry>,
    private val onChanged: () -> Unit
) : RecyclerView.Adapter<ClipAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.clipText)
        val time: TextView = view.findViewById(R.id.clipTime)
        val pin: TextView = view.findViewById(R.id.clipPin)
        val delete: TextView = view.findViewById(R.id.clipDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_clip, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = entries.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = entries[position]
        holder.text.text = entry.text
        holder.text.setTextColor(ThemeManager.textPrimary(context))
        holder.time.text = DateFormat.format("MMM d, h:mm a", entry.timestampMillis)
        holder.time.setTextColor(ThemeManager.textSecondary(context))
        holder.pin.text = if (entry.pinned) "★" else "☆"
        holder.pin.setTextColor(if (entry.pinned) ThemeManager.accentColor(context) else ThemeManager.textSecondary(context))
        holder.delete.setTextColor(ThemeManager.textSecondary(context))

        holder.itemView.setOnClickListener {
            // 🟢 Writing to the clipboard has no restriction — only
            // reading in the background is limited. One-tap "copy back"
            // works reliably from anywhere in Sely.
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Sely clip", entry.text))
            Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
        }
        holder.pin.setOnClickListener {
            ClipboardHistoryStore.togglePin(context, entry)
            onChanged()
        }
        holder.delete.setOnClickListener {
            ClipboardHistoryStore.remove(context, entry)
            onChanged()
        }
    }
}
