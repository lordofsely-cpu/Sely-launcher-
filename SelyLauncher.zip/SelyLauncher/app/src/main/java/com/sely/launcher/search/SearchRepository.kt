package com.sely.launcher.search

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import com.sely.launcher.AppInfo
import com.sely.launcher.AppRepository

/**
 * Sely Search (spec section 8) — data layer.
 *
 * Three real sources, each backed by an official Android API:
 *  🟢 Apps — AppRepository (already built), filtered by label.
 *  🟢 Settings shortcuts — a fixed keyword→Intent map. Every intent
 *     here is a documented public constant (Settings.ACTION_*); tapping
 *     a result opens the real system screen, exactly like the spec's
 *     example ("searching Bluetooth opens Bluetooth settings").
 *  🟢 Contacts — ContactsContract.Contacts.CONTENT_FILTER_URI, the
 *     official live-filter contacts query. Requires READ_CONTACTS,
 *     which the UI requests explicitly (see SearchActivity) rather than
 *     silently failing.
 *
 * No AI, no network — matches spec §8 ("No AI is required. Keep search
 * fast and lightweight").
 */
sealed class SearchResult {
    data class AppResult(val app: AppInfo) : SearchResult()
    data class SettingsResult(val label: String, val icon: Drawable?, val intentAction: String) : SearchResult()
    data class ContactResult(val name: String, val lookupUri: Uri, val photo: Drawable?) : SearchResult()
}

object SearchRepository {

    /** label + the keywords that should surface it + the real Settings intent action. */
    private val settingsShortcuts = listOf(
        Triple("Wi-Fi settings", listOf("wifi", "wi-fi", "internet"), Settings.ACTION_WIFI_SETTINGS),
        Triple("Bluetooth settings", listOf("bluetooth"), Settings.ACTION_BLUETOOTH_SETTINGS),
        Triple("Battery settings", listOf("battery"), Settings.ACTION_BATTERY_SAVER_SETTINGS),
        Triple("Display settings", listOf("display", "screen", "brightness"), Settings.ACTION_DISPLAY_SETTINGS),
        Triple("Sound settings", listOf("sound", "volume", "ringtone"), Settings.ACTION_SOUND_SETTINGS),
        Triple("Storage settings", listOf("storage", "space"), Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
        Triple("App settings", listOf("apps", "application"), Settings.ACTION_APPLICATION_SETTINGS),
        Triple("Location settings", listOf("location", "gps"), Settings.ACTION_LOCATION_SOURCE_SETTINGS),
        Triple("Airplane mode settings", listOf("airplane", "flight mode"), Settings.ACTION_AIRPLANE_MODE_SETTINGS),
        Triple("Date & time settings", listOf("date", "time", "clock"), Settings.ACTION_DATE_SETTINGS),
        Triple("Security settings", listOf("security", "lock", "password"), Settings.ACTION_SECURITY_SETTINGS),
        Triple("Accessibility settings", listOf("accessibility"), Settings.ACTION_ACCESSIBILITY_SETTINGS),
        Triple("NFC settings", listOf("nfc"), Settings.ACTION_NFC_SETTINGS)
    )

    fun searchApps(context: Context, query: String): List<SearchResult.AppResult> {
        if (query.isBlank()) return emptyList()
        return AppRepository.loadLaunchableApps(context)
            .filter { it.label.contains(query, ignoreCase = true) }
            .map { SearchResult.AppResult(it) }
    }

    fun searchSettings(query: String): List<SearchResult.SettingsResult> {
        if (query.isBlank()) return emptyList()
        return settingsShortcuts
            .filter { (label, keywords, _) ->
                label.contains(query, ignoreCase = true) || keywords.any { it.contains(query, ignoreCase = true) }
            }
            .map { (label, _, action) -> SearchResult.SettingsResult(label, null, action) }
    }

    /** Requires READ_CONTACTS to already be granted — callers must check first. */
    fun searchContacts(context: Context, query: String): List<SearchResult.ContactResult> {
        if (query.isBlank()) return emptyList()
        if (context.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        val results = mutableListOf<SearchResult.ContactResult>()
        val uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_FILTER_URI, Uri.encode(query))
        context.contentResolver.query(
            uri,
            arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.LOOKUP_KEY),
            null, null, null
        )?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
            val lookupIdx = cursor.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY)
            val idIdx = cursor.getColumnIndex(ContactsContract.Contacts._ID)
            while (cursor.moveToNext() && results.size < 10) {
                val name = cursor.getString(nameIdx) ?: continue
                val lookupKey = cursor.getString(lookupIdx)
                val id = cursor.getLong(idIdx)
                val contactUri = ContactsContract.Contacts.getLookupUri(id, lookupKey)
                results.add(SearchResult.ContactResult(name, contactUri, null))
            }
        }
        return results
    }
}
