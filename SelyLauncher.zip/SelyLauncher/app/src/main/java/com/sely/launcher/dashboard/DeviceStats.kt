package com.sely.launcher.dashboard

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs

/**
 * Sely Battery Center + Device Dashboard (spec sections 12 & 13).
 *
 * Everything here reads a real, official Android source — nothing is
 * estimated or invented (per spec §12: "Do not invent unavailable
 * battery statistics"):
 *  🟢 Battery percentage/charging/health/temperature — the sticky
 *     ACTION_BATTERY_CHANGED broadcast (registering with a null
 *     receiver returns the last sticky value immediately, no listener
 *     needed for a one-shot read)
 *  🟢 RAM — ActivityManager.MemoryInfo (total/available)
 *  🟢 Storage — StatFs against the data directory (total/free)
 *  🟢 Device info — Build.MODEL/MANUFACTURER/VERSION
 *
 * Battery temperature and health are reported only when Android
 * actually exposes them for the device's battery (EXTRA_TEMPERATURE /
 * EXTRA_HEALTH) — if a value ever came back clearly bogus for a given
 * OEM, the right fix is to hide that field, not fabricate a number.
 */
data class BatterySnapshot(
    val percent: Int,
    val isCharging: Boolean,
    val temperatureCelsius: Float?,
    val healthLabel: String
)

data class MemorySnapshot(val totalBytes: Long, val availableBytes: Long)

data class StorageSnapshot(val totalBytes: Long, val freeBytes: Long)

data class DeviceInfo(val manufacturer: String, val model: String, val androidVersion: String, val sdkInt: Int)

object DeviceStats {

    fun battery(context: Context): BatterySnapshot {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val temperature = if (tenths != Int.MIN_VALUE) tenths / 10f else null

        val health = when (intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown"
        }

        return BatterySnapshot(percent, isCharging, temperature, health)
    }

    fun memory(context: Context): MemorySnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return MemorySnapshot(info.totalMem, info.availMem)
    }

    fun storage(): StorageSnapshot {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.blockCountLong * stat.blockSizeLong
        val free = stat.availableBlocksLong * stat.blockSizeLong
        return StorageSnapshot(total, free)
    }

    fun device(): DeviceInfo = DeviceInfo(
        manufacturer = Build.MANUFACTURER,
        model = Build.MODEL,
        androidVersion = Build.VERSION.RELEASE,
        sdkInt = Build.VERSION.SDK_INT
    )

    fun formatBytes(bytes: Long): String {
        val gb = bytes / 1_073_741_824.0
        return if (gb >= 1) "%.1f GB".format(gb) else "%.0f MB".format(bytes / 1_048_576.0)
    }
}
