package com.sely.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.controlcenter.ControlCenterActivity
import com.sely.launcher.dashboard.DeviceDashboardActivity
import com.sely.launcher.databinding.ActivitySettingsBinding
import com.sely.launcher.drawer.AppDrawerActivity
import com.sely.launcher.multitask.MultitaskHubActivity
import com.sely.launcher.notifications.NotificationCenterActivity
import com.sely.launcher.notifications.SelyNotificationListenerService
import com.sely.launcher.sidebar.SidebarActivity
import com.sely.launcher.theme.ThemeActivity
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Settings (spec section 45) — real menu, not a stub.
 *
 * Two kinds of row:
 *  1. Navigation rows that just open a screen already built
 *     (Themes, Device Dashboard, Recents, App Drawer, Control Center,
 *     Notification Center).
 *  2. Live permission-status rows: subtitle reflects the actual current
 *     grant state (checked fresh in onResume, since the user may have
 *     just come back from the system settings screen it links to) and
 *     the row itself opens the real system screen to change it — same
 *     pattern used throughout Control Center/Dashboard.
 *
 * Rebuilds its row list in onResume so returning from any linked screen
 * (e.g. just granted Notification access) shows the updated status
 * immediately, matching how every other screen here stays live.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        rebuildRows()
    }

    private fun applyTheme() {
        binding.settingsRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
    }

    private fun rebuildRows() {
        // Remove everything except the title (index 0)
        while (binding.settingsContainer.childCount > 1) {
            binding.settingsContainer.removeViewAt(1)
        }

        addSectionHeader("Appearance")
        addRow("Themes", "Accent color, dark / light mode") {
            startActivity(Intent(this, ThemeActivity::class.java))
        }

        addSectionHeader("Launcher")
        addRow("Search", "Apps, settings shortcuts, and contacts") {
            startActivity(Intent(this, com.sely.launcher.search.SearchActivity::class.java))
        }
        addRow("App Drawer", "Search and browse all apps") {
            startActivity(Intent(this, AppDrawerActivity::class.java))
        }
        addRow("Control Center", "Quick toggles, volume, brightness") {
            startActivity(Intent(this, ControlCenterActivity::class.java))
        }
        addRow("Notification Center", "View and manage notifications") {
            startActivity(Intent(this, NotificationCenterActivity::class.java))
        }
        addRow("Sidebar", "Favorites and tools — swipe from the right edge on Home") {
            startActivity(Intent(this, SidebarActivity::class.java))
        }
        addRow("Multitasking", "Apps opened through Sely, most recent and most used") {
            startActivity(Intent(this, MultitaskHubActivity::class.java))
        }
        addRow("Clipboard", "Clips Sely has seen while open, pin your favorites") {
            startActivity(Intent(this, com.sely.launcher.clipboard.ClipboardManagerActivity::class.java))
        }
        addRow("File Hub", "Images, videos, audio, downloads") {
            startActivity(Intent(this, com.sely.launcher.filehub.FileHubActivity::class.java))
        }
        addRow("Battery & Device", "Battery, RAM, storage, device info") {
            startActivity(Intent(this, DeviceDashboardActivity::class.java))
        }

        addSectionHeader("Privacy & Permissions")
        val notifGranted = SelyNotificationListenerService.isEnabled(this)
        addRow("Notification access", if (notifGranted) "Granted" else "Not granted — tap to grant") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        val writeGranted = Settings.System.canWrite(this)
        addRow("Modify system settings", if (writeGranted) "Granted (used for Brightness slider)" else "Not granted — tap to grant") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        addRow("Default launcher", defaultLauncherStatus(), opensDefaultAppsSettings = true)

        addSectionHeader("About")
        addRow(getString(R.string.app_name), getString(R.string.tagline)) { }
    }

    /** Real check: resolves who Android currently treats as the default Home app. */
    private fun defaultLauncherStatus(): String {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = packageManager.resolveActivity(homeIntent, 0)
        return if (resolved?.activityInfo?.packageName == packageName) {
            "Sely is your default Home app"
        } else {
            "Not set as default — tap to choose"
        }
    }

    private fun addRow(label: String, subtitle: String, opensDefaultAppsSettings: Boolean = false, onClick: (() -> Unit)? = null) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_settings_row, binding.settingsContainer, false)
        val labelView = row.findViewById<TextView>(R.id.rowLabel)
        val subtitleView = row.findViewById<TextView>(R.id.rowSubtitle)
        labelView.text = label
        subtitleView.text = subtitle
        labelView.setTextColor(ThemeManager.textPrimary(this))
        subtitleView.setTextColor(ThemeManager.textSecondary(this))
        row.setOnClickListener {
            if (opensDefaultAppsSettings) {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } else {
                onClick?.invoke()
            }
        }
        binding.settingsContainer.addView(row)
    }

    private fun addSectionHeader(title: String) {
        val header = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(ThemeManager.accentColor(this@SettingsActivity))
            setPadding(0, dp(20), 0, dp(8))
        }
        binding.settingsContainer.addView(header)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
