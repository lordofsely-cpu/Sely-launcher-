package com.sely.launcher.notifications

import android.service.notification.StatusBarNotification
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R

class NotificationAdapter(
    private val context: android.content.Context,
    private val notifications: List<StatusBarNotification>,
    private val onCleared: (String) -> Unit
) : RecyclerView.Adapter<NotificationAdapter.ViewHolder>() {

    // key -> expanded state, so expand/collapse survives list refreshes
    private val expanded = mutableSetOf<String>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.notifIcon)
        val app: TextView = view.findViewById(R.id.notifApp)
        val title: TextView = view.findViewById(R.id.notifTitle)
        val text: TextView = view.findViewById(R.id.notifText)
        val clear: TextView = view.findViewById(R.id.notifClear)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_notification, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = notifications.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val sbn = notifications[position]
        val extras = sbn.notification.extras
        val pm = context.packageManager

        holder.icon.setImageDrawable(
            try { pm.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        )
        holder.app.text = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }

        holder.title.text = extras.getCharSequence("android.title") ?: ""
        holder.text.text = extras.getCharSequence("android.text") ?: ""

        val isExpanded = expanded.contains(sbn.key)
        holder.text.maxLines = if (isExpanded) 12 else 1

        holder.itemView.setOnClickListener {
            if (isExpanded) expanded.remove(sbn.key) else expanded.add(sbn.key)
            notifyItemChanged(position)
        }

        holder.clear.setOnClickListener { onCleared(sbn.key) }
    }
}
