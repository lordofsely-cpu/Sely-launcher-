package com.sely.launcher.gesture

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import kotlin.math.abs

/**
 * Minimal gesture engine (spec section 7), foundation slice: vertical
 * swipes only. This is the extension point for the rest of the gesture
 * spec (double tap, edge gestures, pinch, customizable bindings) —
 * add cases to onFling / onDoubleTap and expose a settings screen that
 * maps gesture -> action instead of hardcoding it here.
 */
class HomeGestureListener(
    context: Context,
    private val onSwipeUp: () -> Unit,
    private val onSwipeDown: (startY: Float) -> Unit
) : GestureDetector.SimpleOnGestureListener() {

    val detector = GestureDetector(context, this)

    override fun onFling(
        e1: MotionEvent?,
        e2: MotionEvent,
        velocityX: Float,
        velocityY: Float
    ): Boolean {
        if (e1 == null) return false
        val deltaY = e2.y - e1.y
        val deltaX = e2.x - e1.x
        if (abs(deltaY) > abs(deltaX) && abs(deltaY) > 120 && abs(velocityY) > 200) {
            if (deltaY < 0) onSwipeUp() else onSwipeDown(e1.y)
            return true
        }
        return false
    }
}
