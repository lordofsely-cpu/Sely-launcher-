package com.sely.launcher.gesture

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import kotlin.math.abs

/**
 * Detects a horizontal swipe starting within [edgeWidthPx] of either
 * screen edge — the standard trigger for an edge sidebar. Kept separate
 * from HomeGestureListener (vertical swipes) so each gesture type stays
 * simple; MainActivity feeds raw touch events to both.
 */
class EdgeGestureListener(
    context: Context,
    private val screenWidthPx: Int,
    private val edgeWidthPx: Int,
    private val onEdgeSwipe: (fromRightEdge: Boolean) -> Unit
) : GestureDetector.SimpleOnGestureListener() {

    val detector = GestureDetector(context, this)

    override fun onFling(
        e1: MotionEvent?,
        e2: MotionEvent,
        velocityX: Float,
        velocityY: Float
    ): Boolean {
        if (e1 == null) return false
        val deltaX = e2.x - e1.x
        val deltaY = e2.y - e1.y
        if (abs(deltaX) <= abs(deltaY) || abs(deltaX) < 100 || abs(velocityX) < 200) return false

        val startedNearRightEdge = e1.x > screenWidthPx - edgeWidthPx
        val startedNearLeftEdge = e1.x < edgeWidthPx

        return when {
            startedNearRightEdge && deltaX < 0 -> { onEdgeSwipe(true); true }
            startedNearLeftEdge && deltaX > 0 -> { onEdgeSwipe(false); true }
            else -> false
        }
    }
}
