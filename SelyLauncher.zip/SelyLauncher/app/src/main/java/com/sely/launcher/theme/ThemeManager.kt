package com.sely.launcher.theme

import android.content.Context
import com.sely.launcher.R

/**
 * Sely Theme Engine (spec section 10), core slice.
 *
 * Real persistence (SharedPreferences — 🟢, no permission needed) for:
 *  - accent color (used to tint icons/highlights everywhere)
 *  - dark/light mode (used for background/surface/text colors)
 *
 * This is deliberately a plain getter/setter object rather than a
 * generic "recolor every view via reflection" trick — each screen calls
 * these getters explicitly in its own onCreate/onResume (see
 * MainActivity, ControlCenterActivity, SidebarActivity,
 * AppDrawerActivity for the pattern). That's a few lines of real,
 * traceable code per screen instead of a fragile generic hack, and it's
 * the same pattern to extend to every remaining screen as new modules
 * are added — see README.
 *
 * Not yet built: icon shape (square/circle/squircle — needs a custom
 * icon-masking step in AppGridAdapter), custom fonts, per-app icon
 * overrides, wallpaper-based dynamic accent extraction (would use
 * Android's Palette library against the current wallpaper bitmap).
 */
object ThemeManager {

    private const val PREFS = "sely_theme"
    private const val KEY_ACCENT = "accent_color"
    private const val KEY_DARK = "dark_mode"

    enum class Preset(val label: String, val colorRes: Int) {
        SELY_BLUE("Sely Blue", R.color.sely_accent_blue_preset),
        SELY_NEON("Sely Neon", R.color.sely_accent_neon),
        SELY_PURPLE("Sely Purple", R.color.sely_accent_purple_preset)
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun accentColor(context: Context): Int {
        val default = context.getColor(R.color.sely_accent_blue_preset)
        return prefs(context).getInt(KEY_ACCENT, default)
    }

    fun setAccentColor(context: Context, color: Int) {
        prefs(context).edit().putInt(KEY_ACCENT, color).apply()
    }

    fun isDark(context: Context): Boolean = prefs(context).getBoolean(KEY_DARK, true)

    fun setDark(context: Context, dark: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK, dark).apply()
    }

    fun backgroundColor(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_bg_deep else R.color.sely_bg_light)

    fun surfaceGlassColor(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_surface_glass else R.color.sely_surface_glass_light)

    fun dockColor(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_dock_bg else R.color.sely_dock_bg_light)

    fun textPrimary(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_text_primary else R.color.sely_text_primary_light)

    fun textSecondary(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_text_secondary else R.color.sely_text_secondary_light)
}
